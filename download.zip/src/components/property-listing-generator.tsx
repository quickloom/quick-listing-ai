"use client";

import { useState } from "react";
import {
  PropertyForm,
  type PropertyFormValues,
} from "@/components/property-form";
import {
  ContentDisplay,
  type GeneratedContent,
} from "@/components/content-display";
import { generatePropertyDescription } from "@/ai/flows/generate-property-description";
import { generateSocialMediaCaptions } from "@/ai/flows/generate-social-media-captions";
import { generateSeoMetadata } from "@/ai/flows/generate-seo-metadata";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal } from "lucide-react";

export function PropertyListingGenerator() {
  const [generatedContent, setGeneratedContent] =
    useState<GeneratedContent | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFormSubmit = async (data: PropertyFormValues) => {
    setIsLoading(true);
    setError(null);
    setGeneratedContent(null);

    const commonInput = {
      propertyType: data.propertyType,
      location: data.location,
      price: data.price,
      size: data.size,
      features: data.features,
      amenities: data.amenities,
    };

    try {
      const [description, captions, seo] = await Promise.all([
        generatePropertyDescription(commonInput),
        generateSocialMediaCaptions(commonInput),
        generateSeoMetadata(commonInput),
      ]);

      setGeneratedContent({
        description: description.description,
        facebook: captions.facebookCaption,
        instagram: captions.instagramCaption,
        linkedin: captions.linkedInCaption,
        metaTitle: seo.metaTitle,
        metaDescription: seo.metaDescription,
      });
    } catch (e) {
      console.error(e);
      setError("Failed to generate content. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid gap-8 md:grid-cols-2">
      <div className="flex flex-col gap-4">
        <h2 className="font-headline text-3xl font-bold">Property Details</h2>
        <p className="text-muted-foreground">
          Fill in the details below to generate marketing content for your
          property.
        </p>
        <PropertyForm onSubmit={handleFormSubmit} isLoading={isLoading} />
      </div>
      <div className="flex flex-col gap-4">
        <h2 className="font-headline text-3xl font-bold">Generated Content</h2>
        <p className="text-muted-foreground">
          AI-powered content will appear here. You can edit and copy it.
        </p>
        {error && (
          <Alert variant="destructive">
            <Terminal className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <ContentDisplay content={generatedContent} isLoading={isLoading} />
      </div>
    </div>
  );
}
