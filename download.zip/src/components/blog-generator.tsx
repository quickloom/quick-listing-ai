"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  generateBlogPost,
  type GenerateBlogPostOutput,
} from "@/ai/flows/generate-blog-post";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal, Wand2 } from "lucide-react";
import { GeneratedCard } from "./generated-card";

const formSchema = z.object({
  city: z.string().min(2, "City name is required."),
});

type BlogFormValues = z.infer<typeof formSchema>;

export function BlogGenerator() {
  const [generatedPost, setGeneratedPost] =
    useState<GenerateBlogPostOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const form = useForm<BlogFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      city: "Austin",
    },
  });

  const handleFormSubmit = async (data: BlogFormValues) => {
    setIsLoading(true);
    setError(null);
    setGeneratedPost(null);
    try {
      const post = await generateBlogPost({ city: data.city });
      setGeneratedPost(post);
    } catch (e) {
      console.error(e);
      setError("Failed to generate blog post. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const LoadingSkeleton = () => (
    <Card>
      <CardHeader>
        <Skeleton className="h-8 w-3/4" />
      </CardHeader>
      <CardContent className="space-y-4">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
        <Skeleton className="h-4 w-full" />
      </CardContent>
    </Card>
  );

  return (
    <div className="grid gap-8 md:grid-cols-2">
      <div className="flex flex-col gap-4">
        <h2 className="font-headline text-3xl font-bold">Blog Post Idea</h2>
        <p className="text-muted-foreground">
          Enter a city to generate a blog post about why it's a great place for
          real estate investment.
        </p>
        <Card>
          <CardHeader>
            <CardTitle>Blog Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form
                onSubmit={form.handleSubmit(handleFormSubmit)}
                className="space-y-6"
              >
                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Miami" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={isLoading} className="w-full">
                  {isLoading ? (
                    "Generating..."
                  ) : (
                    <>
                      <Wand2 className="mr-2 h-4 w-4" /> Generate Post
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>

      <div className="flex flex-col gap-4">
        <h2 className="font-headline text-3xl font-bold">
          Generated Blog Post
        </h2>
        <p className="text-muted-foreground">
          Your AI-generated blog post will appear here.
        </p>
        {error && (
          <Alert variant="destructive">
            <Terminal className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {isLoading && <LoadingSkeleton />}
        {!isLoading && !generatedPost && (
          <div className="flex h-full items-center justify-center rounded-lg border-2 border-dashed bg-card p-8 text-center text-muted-foreground">
            Your AI-generated content will appear here once you submit the form.
          </div>
        )}
        {generatedPost && (
          <div className="space-y-4">
            <GeneratedCard title="Blog Title" content={generatedPost.title} />
            <GeneratedCard
              title="Blog Content"
              content={generatedPost.content}
            />
          </div>
        )}
      </div>
    </div>
  );
}
