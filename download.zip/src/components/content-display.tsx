"use client";

import { GeneratedCard } from "@/components/generated-card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Languages,
  Facebook,
  Instagram,
  Linkedin,
  FileText,
  Megaphone,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export interface GeneratedContent {
  description: string;
  facebook: string;
  instagram: string;
  linkedin: string;
  metaTitle: string;
  metaDescription: string;
}

interface ContentDisplayProps {
  content: GeneratedContent | null;
  isLoading: boolean;
}

const LoadingSkeleton = () => (
  <div className="space-y-4">
    <Skeleton className="h-48 w-full" />
    <Skeleton className="h-32 w-full" />
    <Skeleton className="h-32 w-full" />
  </div>
);

export function ContentDisplay({ content, isLoading }: ContentDisplayProps) {
  if (isLoading) {
    return <LoadingSkeleton />;
  }

  if (!content) {
    return (
      <div className="flex h-full items-center justify-center rounded-lg border-2 border-dashed bg-card p-8 text-center text-muted-foreground">
        Your AI-generated content will appear here once you submit the form.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-end gap-2">
        <Languages className="h-5 w-5 text-muted-foreground" />
        <Select defaultValue="en">
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Language" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="en">English</SelectItem>
            <SelectItem value="es">Spanish</SelectItem>
            <SelectItem value="fr">French</SelectItem>
            <SelectItem value="de">German</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <GeneratedCard
        title="Long-form Description"
        content={content.description}
        icon={<FileText />}
      />
      <GeneratedCard
        title="Facebook Caption"
        content={content.facebook}
        icon={<Facebook />}
      />
      <GeneratedCard
        title="Instagram Caption"
        content={content.instagram}
        icon={<Instagram />}
      />
      <GeneratedCard
        title="LinkedIn Caption"
        content={content.linkedin}
        icon={<Linkedin />}
      />
      <GeneratedCard
        title="SEO Meta Title"
        content={content.metaTitle}
        icon={<Megaphone />}
      />
      <GeneratedCard
        title="SEO Meta Description"
        content={content.metaDescription}
        icon={<Megaphone />}
      />
    </div>
  );
}
