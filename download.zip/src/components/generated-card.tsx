"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clipboard, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";

interface GeneratedCardProps {
  title: string;
  content: string;
  icon?: React.ReactNode;
}

export function GeneratedCard({ title, content, icon }: GeneratedCardProps) {
  const [copied, setCopied] = useState(false);
  const [editedContent, setEditedContent] = useState(content);
  const { toast } = useToast();

  const handleCopy = () => {
    navigator.clipboard.writeText(editedContent);
    setCopied(true);
    toast({
      title: "Copied to clipboard!",
      description: `${title} has been copied.`,
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card className="shadow-md transition-shadow hover:shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="flex items-center gap-2 text-xl font-headline">
          {icon}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Textarea
          value={editedContent}
          onChange={(e) => setEditedContent(e.target.value)}
          className="h-auto min-h-[100px] w-full resize-y border-0 bg-transparent p-0 text-base focus-visible:ring-0 focus-visible:ring-offset-0"
        />
      </CardContent>
      <CardFooter>
        <Button
          onClick={handleCopy}
          variant="ghost"
          size="sm"
          className="ml-auto"
        >
          {copied ? (
            <>
              <Check className="mr-2 h-4 w-4 text-green-500" /> Copied
            </>
          ) : (
            <>
              <Clipboard className="mr-2 h-4 w-4" /> Copy
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
