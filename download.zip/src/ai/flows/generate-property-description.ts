'use server';

/**
 * @fileOverview AI agent that generates long-form property descriptions.
 *
 * - generatePropertyDescription - A function that generates property descriptions.
 * - GeneratePropertyDescriptionInput - The input type for the generatePropertyDescription function.
 * - GeneratePropertyDescriptionOutput - The return type for the generatePropertyDescription function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GeneratePropertyDescriptionInputSchema = z.object({
  propertyType: z.string().describe('The type of property (e.g., house, apartment, condo).'),
  location: z.string().describe('The location of the property (city, neighborhood).'),
  price: z.number().describe('The price of the property.'),
  size: z.number().describe('The size of the property in square feet.'),
  features: z.string().describe('Key features of the property (e.g., hardwood floors, modern kitchen).'),
  amenities: z.string().describe('Amenities near the property (e.g., parks, schools, restaurants).'),
});
export type GeneratePropertyDescriptionInput = z.infer<
  typeof GeneratePropertyDescriptionInputSchema
>;

const GeneratePropertyDescriptionOutputSchema = z.object({
  description: z.string().describe('The generated long-form property description.'),
});
export type GeneratePropertyDescriptionOutput = z.infer<
  typeof GeneratePropertyDescriptionOutputSchema
>;

export async function generatePropertyDescription(
  input: GeneratePropertyDescriptionInput
): Promise<GeneratePropertyDescriptionOutput> {
  return generatePropertyDescriptionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generatePropertyDescriptionPrompt',
  input: {schema: GeneratePropertyDescriptionInputSchema},
  output: {schema: GeneratePropertyDescriptionOutputSchema},
  prompt: `You are a real estate agent who writes compelling property descriptions.

  Using the provided details, write a long-form description of the property that highlights its key features and benefits.

  Property Type: {{propertyType}}
  Location: {{location}}
  Price: {{price}}
  Size: {{size}} sq ft
  Features: {{features}}
  Amenities: {{amenities}}`,
});

const generatePropertyDescriptionFlow = ai.defineFlow(
  {
    name: 'generatePropertyDescriptionFlow',
    inputSchema: GeneratePropertyDescriptionInputSchema,
    outputSchema: GeneratePropertyDescriptionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
