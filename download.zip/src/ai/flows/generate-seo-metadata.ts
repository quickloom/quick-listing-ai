'use server';

/**
 * @fileOverview Flow for generating SEO meta titles and descriptions based on property details.
 *
 * - generateSeoMetadata - A function that handles the SEO meta title and description generation.
 * - GenerateSeoMetadataInput - The input type for the generateSeoMetadata function.
 * - GenerateSeoMetadataOutput - The return type for the generateSeoMetadata function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateSeoMetadataInputSchema = z.object({
  propertyType: z.string().describe('The type of the property (e.g., house, apartment, condo).'),
  location: z.string().describe('The location of the property (city, state).'),
  price: z.number().describe('The price of the property.'),
  size: z.number().describe('The size of the property in square feet.'),
  features: z.string().describe('Key features of the property (e.g., hardwood floors, updated kitchen).'),
  amenities: z.string().describe('Amenities near the property (e.g., parks, schools, shopping).'),
});

export type GenerateSeoMetadataInput = z.infer<typeof GenerateSeoMetadataInputSchema>;

const GenerateSeoMetadataOutputSchema = z.object({
  metaTitle: z.string().describe('The SEO meta title for the property listing.'),
  metaDescription: z.string().describe('The SEO meta description for the property listing.'),
});

export type GenerateSeoMetadataOutput = z.infer<typeof GenerateSeoMetadataOutputSchema>;

export async function generateSeoMetadata(input: GenerateSeoMetadataInput): Promise<GenerateSeoMetadataOutput> {
  return generateSeoMetadataFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateSeoMetadataPrompt',
  input: {schema: GenerateSeoMetadataInputSchema},
  output: {schema: GenerateSeoMetadataOutputSchema},
  prompt: `You are an expert SEO specialist for real estate listings. Generate a compelling meta title and meta description for the following property:

Property Type: {{propertyType}}
Location: {{location}}
Price: {{price}}
Size: {{size}} sq ft
Features: {{features}}
Amenities: {{amenities}}

Meta Title (max 60 characters):
Meta Description (max 160 characters):`,
});

const generateSeoMetadataFlow = ai.defineFlow(
  {
    name: 'generateSeoMetadataFlow',
    inputSchema: GenerateSeoMetadataInputSchema,
    outputSchema: GenerateSeoMetadataOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
