'use server';
/**
 * @fileOverview Generates short social media captions for property listings.
 *
 * - generateSocialMediaCaptions - A function that generates social media captions.
 * - GenerateSocialMediaCaptionsInput - The input type for the generateSocialMediaCaptions function.
 * - GenerateSocialMediaCaptionsOutput - The return type for the generateSocialMediaCaptions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateSocialMediaCaptionsInputSchema = z.object({
  propertyType: z.string().describe('The type of property (e.g., house, apartment, condo).'),
  location: z.string().describe('The location of the property (city, neighborhood).'),
  price: z.number().describe('The price of the property.'),
  size: z.number().describe('The size of the property in square feet.'),
  features: z.string().describe('Key features of the property (e.g., hardwood floors, updated kitchen, large yard).'),
  amenities: z.string().describe('Nearby amenities (e.g., schools, parks, restaurants).'),
});
export type GenerateSocialMediaCaptionsInput = z.infer<typeof GenerateSocialMediaCaptionsInputSchema>;

const GenerateSocialMediaCaptionsOutputSchema = z.object({
  facebookCaption: z.string().describe('A short social media caption for Facebook.'),
  instagramCaption: z.string().describe('A short social media caption for Instagram.'),
  linkedInCaption: z.string().describe('A short social media caption for LinkedIn.'),
});
export type GenerateSocialMediaCaptionsOutput = z.infer<typeof GenerateSocialMediaCaptionsOutputSchema>;

export async function generateSocialMediaCaptions(input: GenerateSocialMediaCaptionsInput): Promise<GenerateSocialMediaCaptionsOutput> {
  return generateSocialMediaCaptionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateSocialMediaCaptionsPrompt',
  input: {schema: GenerateSocialMediaCaptionsInputSchema},
  output: {schema: GenerateSocialMediaCaptionsOutputSchema},
  prompt: `You are a real estate marketing expert. Generate short, engaging social media captions for a property listing on Facebook, Instagram, and LinkedIn.

Property Type: {{{propertyType}}}
Location: {{{location}}}
Price: {{{price}}}
Size: {{{size}}} sq ft
Features: {{{features}}}
Amenities: {{{amenities}}}

Write a captivating Facebook caption:

Write a captivating Instagram caption:

Write a captivating LinkedIn caption:`,
});

const generateSocialMediaCaptionsFlow = ai.defineFlow(
  {
    name: 'generateSocialMediaCaptionsFlow',
    inputSchema: GenerateSocialMediaCaptionsInputSchema,
    outputSchema: GenerateSocialMediaCaptionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
