import { config } from 'dotenv';
config();

import '@/ai/flows/generate-social-media-captions.ts';
import '@/ai/flows/generate-property-description.ts';
import '@/ai/flows/generate-seo-metadata.ts';
import '@/ai/flows/generate-blog-post.ts';