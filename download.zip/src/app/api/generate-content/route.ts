import {NextResponse} from 'next/server';
import * as z from 'zod';

import {generatePropertyDescription} from '@/ai/flows/generate-property-description';
import {generateSocialMediaCaptions} from '@/ai/flows/generate-social-media-captions';
import {generateSeoMetadata} from '@/ai/flows/generate-seo-metadata';

// Schema for validating the input from the request body.
const inputSchema = z.object({
  propertyType: z.string().min(1, 'Please select a property type.'),
  location: z.string().min(2, 'Location is required.'),
  price: z.coerce.number().positive('Price must be a positive number.'),
  size: z.coerce.number().positive('Size must be a positive number.'),
  features: z.string().min(10, 'Please describe at least some features.'),
  amenities: z.string().min(10, 'Please describe at least some amenities.'),
});

/**
 * API route handler for generating property marketing content.
 * @param request - The incoming POST request.
 * @returns A JSON response with the generated content or an error message.
 */
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const data = inputSchema.parse(body);

    const commonInput = {
      propertyType: data.propertyType,
      location: data.location,
      price: data.price,
      size: data.size,
      features: data.features,
      amenities: data.amenities,
    };

    // Call all the generation flows in parallel for efficiency.
    const [description, captions, seo] = await Promise.all([
      generatePropertyDescription(commonInput),
      generateSocialMediaCaptions(commonInput),
      generateSeoMetadata(commonInput),
    ]);

    const generatedContent = {
      description: description.description,
      facebook: captions.facebookCaption,
      instagram: captions.instagramCaption,
      linkedin: captions.linkedInCaption,
      metaTitle: seo.metaTitle,
      metaDescription: seo.metaDescription,
    };

    return NextResponse.json(generatedContent);
  } catch (error) {
    console.error('[API_GENERATE_CONTENT_ERROR]', error);
    if (error instanceof z.ZodError) {
      return new NextResponse('Invalid input provided.', {status: 400});
    }
    return new NextResponse('Internal Server Error', {status: 500});
  }
}
