
"use client";

import { Bot, Home as HomeIcon, Newspaper } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PropertyListingGenerator } from "@/components/property-listing-generator";
import { BlogGenerator } from "@/components/blog-generator";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Home() {
  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b bg-background/80 px-4 backdrop-blur md:px-6">
        <div className="flex items-center gap-2">
          <Bot className="h-6 w-6 text-primary" />
          <h1 className="font-headline text-2xl font-bold text-foreground">
            Quick AI Listing
          </h1>
        </div>
        <ThemeToggle />
      </header>

      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6">
        <div className="mx-auto w-full max-w-6xl">
          <Tabs defaultValue="property-listing" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="property-listing">
                <HomeIcon className="mr-2 h-4 w-4" />
                Property Listing
              </TabsTrigger>
              <TabsTrigger value="blog-post">
                <Newspaper className="mr-2 h-4 w-4" />
                Blog Post
              </TabsTrigger>
            </TabsList>
            <TabsContent value="property-listing">
              <PropertyListingGenerator />
            </TabsContent>
            <TabsContent value="blog-post">
              <BlogGenerator />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <footer className="border-t py-4 text-center text-sm text-muted-foreground">
        <p>
          Powered by Quick AI Listing. © {new Date().getFullYear()}. All rights reserved.
        </p>
      </footer>
    </div>
  );
}
